
# Bybit Anti-Manipulation Bot

## Ce face:
- Preia date live de la Bybit
- Calculează RSI, EMA50/200, ATR
- Detectează semnale LONG / SHORT inteligente
- NU plasează încă ordine reale — doar simulează intrări

## Cum îl rulezi:
1. Instalează librăriile: `pip install pandas requests numpy`
2. Pune API_KEY și API_SECRET în fișierul bybit_bot.py
3. Rulează: `python bybit_bot.py`

Versiunea viitoare va executa ordine reale automat prin API.
