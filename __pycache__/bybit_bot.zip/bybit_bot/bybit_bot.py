
import time
import hmac
import hashlib
import requests
import pandas as pd
from datetime import datetime
import numpy as np

# === CONFIG ===
API_KEY = 'YOUR_API_KEY'
API_SECRET = 'YOUR_API_SECRET'
SYMBOL = 'BTCUSDT'
TIMEFRAME = '15'  # minute
POSITION_SIZE = 20  # USDT
LEVERAGE = 2
TP_PERCENT = 1.5
SL_PERCENT = 0.8
BASE_URL = 'https://api.bybit.com'

# === FUNCȚII DE API ===
def get_server_time():
    return int(time.time() * 1000)

def sign_request(params):
    query = '&'.join([f"{k}={v}" for k, v in sorted(params.items())])
    signature = hmac.new(
        bytes(API_SECRET, "utf-8"),
        bytes(query, "utf-8"),
        hashlib.sha256
    ).hexdigest()
    return signature

def get_klines(symbol, interval, limit=100):
    url = f"{BASE_URL}/v5/market/kline"
    params = {
        'category': 'linear',
        'symbol': symbol,
        'interval': interval,
        'limit': limit
    }
    response = requests.get(url, params=params)
    data = response.json()
    df = pd.DataFrame(data['result']['list'], columns=[
        'timestamp', 'open', 'high', 'low', 'close', 'volume', '_1', '_2', '_3', '_4', '_5'
    ])
    df['open'] = df['open'].astype(float)
    df['high'] = df['high'].astype(float)
    df['low'] = df['low'].astype(float)
    df['close'] = df['close'].astype(float)
    df['volume'] = df['volume'].astype(float)
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df[['timestamp', 'open', 'high', 'low', 'close', 'volume']]

# === STRATEGIE ===
def calculate_indicators(df):
    df['EMA50'] = df['close'].ewm(span=50).mean()
    df['EMA200'] = df['close'].ewm(span=200).mean()
    df['RSI'] = compute_rsi(df['close'])
    df['ATR'] = compute_atr(df, period=14)
    return df

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def compute_atr(df, period=14):
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = ranges.max(axis=1)
    return true_range.rolling(period).mean()

# === EXECUTARE ===
def main():
    print("Botul rulează...")

    while True:
        try:
            df = get_klines(SYMBOL, TIMEFRAME)
            df = calculate_indicators(df)
            latest = df.iloc[-1]

            if np.isnan(latest['RSI']) or np.isnan(latest['EMA50']) or np.isnan(latest['EMA200']):
                time.sleep(60)
                continue

            if latest['RSI'] < 30 and latest['close'] > latest['EMA50']:
                print("📈 Semnal LONG")
            elif latest['RSI'] > 70 and latest['close'] < latest['EMA50']:
                print("📉 Semnal SHORT")
            else:
                print("⏳ Niciun semnal valid")

        except Exception as e:
            print(f"❌ Eroare: {e}")

        time.sleep(60 * int(TIMEFRAME))  # Așteaptă cât e timeframe-ul

if __name__ == '__main__':
    main()
